# pages/views.py
from django.http import HttpResponse
import json
'''
importing required
packages is very
important
for
proper excution of
django project'''
def homePageView(request):
    #lojfdg oiduu7yi
    data = {
        "message" : "Hello World!"
    }
    
    dump = json.dumps(data)
    #lojfdg oiduu7yi
    #lojfdg oiduu7yi
    return HttpResponse(dump, content_type='application/json')
'''once this page is ended the json obj is displayed on page'''
